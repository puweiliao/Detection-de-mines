#include <iostream>
#include<cmath>
#include<vector>
#include<cstdlib>

#include "assemblage.h"
#include "resol_temp.h"

using namespace std;

int main()
{

    Maillage Maill = Maillage();  //d�claration du maillage
    int N= Maill.taille_maillage();

    //declaration des variables du probl�me

    double lambda_roche = 1;
    double lambda_terre = 1;
    double lambda_mines = 1;

    double mu_roche=1;
    double mu_terre=1;
    double mu_mines=1;

    double rho_roche=1;
    double rho_terre=1;
    double rho_mines=1;



//    double lambda_roche = 70* 1e9 *0.2/((1+0.2)*(1-2*0.2));
//    double lambda_terre = 2.25*1e9*0.35/((1+0.35)*(1-2*0.35));
//    double lambda_mines = 210*1e9*0.3/((1+0.3)*(1-2*0.3));
//
//    double mu_roche=70*1e9/(2*(1+0.2));
//    double mu_terre=2.25*1e9/(2*(1+0.35));
//    double mu_mines=210*1e9/(2*(1+0.3));
//
//    double rho_roche=2500;
//    double rho_terre=1250;
//    double rho_mines=7850;

    double t_0 = 0;
    double t_max = 0.8;
    double dt =0.01;

    //conditions initiales
    Vecteur U(2*N);    //on prend 0 comme conditions initiales
    Vecteur V(2*N);






    //utilisateurs : ne pas toucher � la suite !!!

    double VS_roche=sqrt((lambda_roche+2*mu_roche)/rho_roche);
    double VP_roche=sqrt(mu_roche/rho_roche);

    double VS_terre=sqrt((lambda_terre+2*mu_terre)/rho_terre);
    double VP_terre=sqrt(mu_terre/rho_terre);

    double VS_mines=sqrt((lambda_mines+2*mu_mines)/rho_mines);
    double VP_mines=sqrt(mu_mines/rho_mines);


    double* rho = new double(3);
    rho[0]=rho_roche;
    rho[1]=rho_terre;
    rho[2]=rho_mines;

    double* lambda = new double(3);
    lambda[0]=lambda_roche;
    lambda[1]=lambda_terre;
    lambda[2]=lambda_mines;

    double* mu = new double(3);
    mu[0]=mu_roche;
    mu[1]=mu_terre;
    mu[2]=mu_mines;

    double* VP = new double(3);
    VP[0]=VP_roche;
    VP[1]=VP_terre;
    VP[2]=VP_mines;

    double* VS = new double(3);
    VS[0]=VS_roche;
    VS[1]=VS_terre;
    VS[2]=VS_mines;


    //Maill.affiche();

    //assemblage de la matrice de masse
    Matrice M1_1= Matrice(N,N);
    Matrice M1_2= Matrice(N,N);
    Matrice M2_1= Matrice(N,N);
    Matrice M2_2= Matrice(N,N);
    assembl_masse(M1_1, M1_2, M2_1,M2_2, Maill, rho);


    Matrice M = construction(M1_1, M1_2, M2_1,M2_2);
    Matrice D= build_D(M);

    //assemblage de la matrice de masse surfacique
    Matrice T1_1= Matrice(N,N);
    Matrice T1_2= Matrice(N,N);
    Matrice T2_1= Matrice(N,N);
    Matrice T2_2= Matrice(N,N);
    assembl_surf(T1_1, T1_2, T2_1,T2_2, Maill,rho, VS,VP);


    Matrice T = construction(T1_1, T1_2, T2_1,T2_2);

//
//    //assemblage de la matrice de rigidit�
    Matrice K1_1= Matrice(N,N);
    Matrice K1_2= Matrice(N,N);
    Matrice K2_1= Matrice(N,N);
    Matrice K2_2= Matrice(N,N);
    assembl_rig(K1_1, K1_2, K2_1,K2_2, Maill,lambda,mu);

    Matrice K = construction(K1_1, K1_2, K2_1,K2_2);

    Matrice T_surf = mat_F(Maill);
//
//    cout << M.est_sym() << endl;
//    cout << T.est_sym() << endl;
//    cout << K.est_sym() << endl;
//    cout << (T_surf).est_sym() << endl;
//

    //matrice utilis�e dans le calcul du second membre



    Vecteur F(2*N);
    F=composante_F(T_surf,Maill, 0);

    std::ofstream ofs;
    ofs.open("resultat.txt", std::ofstream::out | std::ofstream::trunc);
    ofs.close();
    ofs.open("n.txt", std::ofstream::out | std::ofstream::trunc);
    ofs.close();


    int n = int ((t_max-t_0)/dt);
    fstream fich;
    fich.open("n.txt", ios::out);
    fich << n << endl;
    fich << dt << endl;
    fich.close();
    F=composante_F(T_surf,Maill, 0);
    U=F;

    for(int i =0;i<n;i++)
    {
        F=composante_F(T_surf,Maill, i*dt+t_0);
        evol_temp( U, V, F, dt,  K,  D,  T);
        //cout << U;
        U.ecrire();
    }
   // system("Octave -nosplash -r \"run('myscript.m')\"");

return 0;

}

