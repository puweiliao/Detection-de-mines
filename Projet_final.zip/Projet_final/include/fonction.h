#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED

#include <cmath>

//c'est l'endroit o� d�finir la fonction qui repr�sente la force agissant sur la partie haute
double* f(double x, double t);



#endif // FONCTION_H_INCLUDED
