#ifndef NUMEROS_H
#define NUMEROS_H
#include"Vecteur.h"
#include<iostream>
using namespace std;

class Numeros : public std::vector<int>
{
    public:
        Numeros(int i=0, int j=0, int k=0);
        int& operator()(int num);
        int operator()(int num) const;
        Numeros shift(int s)const;

    protected:

    private:

};

ostream & operator <<(ostream & out, const Numeros N);


#endif // NUMEROS_H
