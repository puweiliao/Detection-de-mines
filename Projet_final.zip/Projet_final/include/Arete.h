#ifndef ARETE_H
#define ARETE_H

#include"Vecteur.h"
#include<iostream>
using namespace std;

class Arete : public std::vector<int>
{
    public:
        Arete(int i=0, int j=0, int k=0, int l=0, int m=0);
        int& operator()(int num);
        int operator()(int num) const;

    protected:

    private:

};

ostream & operator <<(ostream & out, const Arete A);
#endif // ARETE_H
