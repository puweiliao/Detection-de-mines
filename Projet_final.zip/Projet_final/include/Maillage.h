#ifndef MAILLAGE_H
#define MAILLAGE_H
#include "Numeros.h"
#include "Point2D.h"
#include "Arete.h"
#include "Matrice.h"
#include<vector>
#include<fstream>
#include<list>
#include<iostream>
using namespace std;

class Maillage
{
    public:

        void lecture_msh(vector<Point2D> & list_noeuds, vector<Numeros> & list_num ,vector<int> & list_zone,vector<Arete> & list_aretes, vector<vector <int> > & M);
        Maillage(); //(meme que lecture,appelle lecture)

        void affiche() const;

        int nb_tri(){return Num_Tri.size();}
        int taille_maillage(){return Noeuds.size();}
        int nb_face_front(){return Surface.size();}


        Numeros& num_tri(int l){return Num_Tri[l-1];}
        Numeros num_tri(int l) const{return Num_Tri[l-1];}

        Point2D noeud(int i){return Noeuds[i-1];}
        int zone(int i){return Zone[i-1];}

    public:
        vector<Point2D> Noeuds;     //vecteur de point : Noeuds[i] contient la position du i-�me noeud
        vector<Numeros> Num_Tri;    //vecteur de triplet : Num_Tri[l] contient les num�ros des sommets compposant le triangle num�ro l
        vector<int> Zone;           //Zone[l] contient la zone dans laquelle est situ�e le l-i�me triangle (1 pour la roche, 2 pour la terre, 3 pour les mines)

        vector<Arete> Surface;
        //vecteur de qintuplet : Surface[i] contient :
       //le premier et le second indice repr�sentent le num�ro des sommets de l'arr�te
        //le 3 �me est les num�ros du sommets formant un triangle avec les 2 pr�c�dents
        //le 4�me est l'indice de la surface :
        //0 pour la surface,1 pour les cot�s, 2 pour le fond
        //le dernier est la zone dans laquelle se situe l'ar�te

};
#endif // MAILLAGE_H






//am�liorer la construction de Surface(construire Surface en m�me temps que Noeuds au lieu de faire 2 parcours)
