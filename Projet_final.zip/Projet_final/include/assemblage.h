#ifndef ASSEMBLAGE_H_INCLUDED
#define ASSEMBLAGE_H_INCLUDED
#include"Maillage.h"
#include "Numeros.h"
#include "Point2D.h"
#include"Matrice.h"
#include "fonction.h"

Matrice mat_masse_elem(double D,double rho);        //matrice de masse �lementaire
void assembl_masse(Matrice& M1_1,Matrice& M1_2, Matrice& M2_1,Matrice& M2_2, Maillage M, double* rho);

Matrice mat_surf_elem(double D, double rho, int indice_ij, int indice_surface,double VS, double VP);       //matrice surfacique �lementaire
void assembl_surf(Matrice& T1_1,Matrice& T1_2, Matrice& T2_1, Matrice& T2_2, Maillage M,double* rho, double* V_S,double* V_P);

Matrice mat_rig_elem_1(int i, int j, double x1,double x2,double x3,double y1,double y2,double y3); //matrice de rigidit� �lemntaire
Matrice mat_rig_elem_2(int i, int j, double x1,double x2,double x3,double y1,double y2,double y3); //matrice de rigidit� �lemntaire
void assembl_rig(Matrice& K1_1,Matrice& K1_2, Matrice& K2_1,Matrice& K2_2, Maillage M,double* Lambda, double* Mu);

//assemblage de f
Matrice mat_F_elem(double D);
Matrice mat_F(Maillage M);
Vecteur composante_F(Matrice T_surf,Maillage M, double t);


Matrice build_D(Matrice M);

#endif // ASSEMBLAGE_H_INCLUDED
