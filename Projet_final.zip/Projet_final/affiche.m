clear; close all; clc;
[Nbpt,Nbtri,Coorneu,Refneu,Numtri,Reftri,Nbaretes,Numaretes,Refaretes]=lecture_msh('geom_projet.msh');
fid = fopen('n.txt','r');
data_1=textscan(fid,'%f', 'delimiter','\n');
n=data_1{1}(1);
dt=data_1{1}(2);
fid = fopen('resultat.txt','r');
data=textscan(fid,'%f', 'delimiter','\n');
U=data{1};
size(U)
fclose(fid);
h=figure;
UU_x=U(1:Nbpt );
UU_y=U(Nbpt+1:2*Nbpt);
UU=sqrt((UU_x).^2+(UU_y).^2);
trisurf(Numtri,Coorneu(:,1),Coorneu(:,2),UU);
colormap jet;axis tight; view(2); shading interp;colorbar;
gca.NextPlot = 'replaceChildren';
M(n) = struct('cdata',[],'colormap',[]);
%h.Visible='off';

for i=1:n
  UU_x=U(2*Nbpt*(i-1)+1:2*Nbpt*(i-1)+Nbpt );
  UU_y=U(2*Nbpt*(i-1)+Nbpt+1:2*Nbpt*(i) );
  UU=sqrt((UU_x).^2+(UU_y).^2);
  trisurf(Numtri,Coorneu(:,1),Coorneu(:,2),UU);
  view(2);  shading interp; colorbar;
  title(['Temps = ',  num2str(i*dt)]);
  drawnow
  M(i) = getframe;
end
%h.Visible='on';
movie(M);
%v=VideoWriter('film.mp4','MPEG-4');
%open(v); writeVideo(v,M); close(v);
