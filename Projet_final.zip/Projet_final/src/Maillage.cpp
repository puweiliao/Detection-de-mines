#include "Maillage.h"
using namespace std;

void Maillage::maille_carre_unite(int m, int n)
{
    //construction des sommets
    double dx= 1./m;
    double dy  = 1./n;
    Noeuds.resize((m+1)*(n+1));
    vector<Point2D>::iterator its = Noeuds.begin();
    for(int j=0;j<n+1;j++)
    {
        double y= j*dy;
        for(int i = 0; i<m+1; i++)
            {
                *its = Point2D(i*dx,y);
                *its++;
            }
    }
    //constuction des num�ros des tianggles
    for(int j=0; j<n;j++)
    {
        for(int i =1; i <= m; i++)
        {
            int q=j*(m+1) +i; //coin bas gauche
            Num_Tri.push_back(Numeros(q,q+1,q+m+1));
            Num_Tri.push_back(Numeros(q+1,q+m+1,q+m+2));
        }
    }
    int s= Num_Tri.size();
    int p= Noeuds.size();
    Zone.resize(s);
    Surface.resize(p);
    for(int i = 0;i<p;i++)
    {
        Zone[i]=0;
        Surface[i]=Arete(1,2,3,4);
    }
}

//cette fonction va nous permettre de lire dans un fichier .msh.
//list_noeuds repr�sente ce qui deviendra la liste des noeuds,
//list_num deviendra Num_tri
//list_zone deviendra Zone
//la matrice M est un matrice NxN, qui contient, � l'indice n1,n2
//  0 si n1,n2 n'est pas dans le m�me triangle
//  n3 sinon, o� n3 est le num�ro du 3�me sommet du triangle (n1,n2,n3)

void Maillage::lecture_msh(vector<Point2D> & list_noeuds, vector<Numeros> & list_num ,vector<int> & list_zone,vector<Arete> & list_aretes, vector<vector <int> > & M){
    fstream fich;
    fich.open("geom_projet.msh",ios::in);
    string s;
    double a;
    double coord_x;
    double coord_y;
    Point2D p;
    getline(fich,s);
    getline(fich,s);
    getline(fich,s);
    getline(fich,s);
    int nb_noeuds;
    fich>>nb_noeuds;
    //initialisation de M
    M.resize(nb_noeuds);
    for(int i=0;i<nb_noeuds;i++)
        M[i].resize(nb_noeuds);


    list_noeuds.clear();
    list_noeuds.resize(nb_noeuds);
    for (int i = 0; i < nb_noeuds; i++) {
         fich>>a;          //num de noeuds//
         fich>>coord_x;
         fich>>coord_y;
          fich>>a;      //coord_z//
          p=Point2D(coord_x,coord_y);
          list_noeuds[i]=p;
    }

    getline(fich,s);
    getline(fich,s);
    getline(fich,s);


    int nb_ele;
    fich>>nb_ele;
    list_num.clear();
    list_zone.clear();
    list_aretes.clear();
     //num_ele  type  num_para(2)  domaine  ignorer (triangle)//
    int b, c, domaine, n1, n2, n3;
    Numeros N;
    Arete A;
    for (int i = 0; i < nb_ele; i++)
    {
         fich>>a;
         fich>>b;
         if(b==2){      //on traite le cas triangle//
             fich>>c;
             fich>>domaine;
             list_zone.push_back(domaine);
             fich>>c;
             fich>>n1;
             fich>>n2;
             fich>>n3;
             N=Numeros(n1,n2,n3);
             list_num.push_back(N);

             n1--;n2--;n3--;
             M[n1][n2]=n3;
             M[n1][n3]=n2;
             M[n2][n3]=n1;

             M[n2][n1]=n3;
             M[n3][n1]=n2;
             M[n3][n2]=n1;
         }
         else if(b==1)      //on traite le cas segment
         {
             fich>>c;
             fich>>domaine;
             fich>>c;
             fich>>n1;
             fich>>n2;
             A=Arete(n1,n2,-1,-1,domaine);
             list_aretes.push_back(A);
         }
         else{getline(fich,s);
         }
    }

}


Maillage::Maillage (){
    vector<Numeros> list_num;
    vector<int> list_zone ;
    vector<Point2D> list_noeuds;
    vector<Arete> list_aretes;
    vector <vector <int> > M;
    lecture_msh(list_noeuds,list_num,list_zone,list_aretes, M);

    Noeuds=list_noeuds;
    Num_Tri=list_num;
    Zone=list_zone;
    double x_0,y_0,x_1,y_1,x_2,y_2,x_3,y_3;      //les coordonn��es des sommets extr�mes du rectangle

    x_0=Noeuds[0].Coor_x();
    y_0=Noeuds[0].Coor_y();
    x_1=Noeuds[1].Coor_x();
    y_1=Noeuds[1].Coor_y();
    x_2=Noeuds[2].Coor_x();
    y_2=Noeuds[2].Coor_y();
    x_3=Noeuds[0].Coor_x();
    y_3=Noeuds[0].Coor_y();

//    for(int i =0;i<Noeuds.size();i++)
//    {for(int j=0;j<Noeuds.size();j++)
//        {cout << M[i][j] ;}
//        cout << endl;}


    for(int i=0;i<list_aretes.size();i++)
    {
        int n1=list_aretes[i](1)-1;
        int n2=list_aretes[i](2)-1;
        list_aretes[i](3)=M[n1][n2]+1;


        if (Noeuds[n1].Coor_y()==y_0 && Noeuds[n2].Coor_y()==y_0)     //l'arete est sur le fond
            list_aretes[i](4)=2;
        if (Noeuds[n1].Coor_x()==x_0 && Noeuds[n2].Coor_x()==x_0)     //l'arete est sur le c�t� gauche
            list_aretes[i](4)=1;
        if (Noeuds[n1].Coor_x()==x_1 && Noeuds[n2].Coor_x()==x_1)     //l'arete est sur le c�t� droit
            list_aretes[i](4)=1;
        if (Noeuds[n1].Coor_y()==y_2 && Noeuds[n2].Coor_y()==y_2)     //l'arete est sur la surface
            list_aretes[i](4)=0;

    }

    Surface=list_aretes;

}


void Maillage::affiche() const
{
    cout<<"Numeros des triangles" << endl;
    vector<Numeros>::const_iterator itl;
    int i = 1;
    for(itl = Num_Tri.begin(); itl != Num_Tri.end();itl++)
    {
        cout << "triangle "  << i <<" : " << *itl << endl;
        i++;
    }

    cout<<"Coordonnees des sommets" << endl;
    vector<Point2D>::const_iterator itv;
    i=1;
    for(itv = Noeuds.begin(); itv != Noeuds.end();itv++)
    {
        cout << "sommet "  << i <<" : " << *itv << endl;
        i++;
    }
//    cout <<"Zone des sommets " <<endl;
//    vector<int>::const_iterator itz;
//    i=1;
//    for(itz = Zone.begin(); itz != Zone.end();itz++)
//    {
//        cout << "sommet "  << i <<" est en zone: " << *itz << endl;
//        i++;
//    }

    cout << "Aretes" << endl;
    vector<Arete>::const_iterator ita;
    i=1;
        for(ita = Surface.begin(); ita != Surface.end();ita++)
    {
        cout << "arete "  << i <<" se compose des sommets " << (*ita)(1) << " et " << (*ita)(2) << ". dernier sommet : " << (*ita)(3) << endl;
        cout << "zone de l'arete " << (*ita)(4) << endl;
        i++;
    }

}

