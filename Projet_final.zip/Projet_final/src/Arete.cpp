#include "Arete.h"
using namespace std;


Arete::Arete(int i, int j, int k, int l,int m)
{
    resize(5);
    (*this)[0]=i;//ctor
    (*this)[1]=j;
    (*this)[2]=k;
    (*this)[3]=l;
    (*this)[4]=m;

}

int& Arete::operator()(int num)
{
    return (*this)[num-1];
}

int Arete::operator()(int num) const
{
    return (*this)[num-1];
}

ostream & operator <<(ostream & out, const Arete A)
{
    out <<"(" << A(1) << " " <<  A(2) << " "  <<A(3) << " " << A(4) << " " <<  A(5) << ")" ;
    return out;
}
