#include "fonction.h"
double* f(double x, double t)
{
    double *tab=new double[2];
    if (t<=0.01){
        tab[0]=1;
        tab[1]=0;
    }
    else{
        tab[0]=0;
        tab[1]=0;
    }
    return tab;
}
